package app.Classes;

import java.sql.*;
import javax.swing.JOptionPane;

public class ConnectionDataBase {
    public static Connection connect() {
    Connection conn = null;

    try {
        conn = DriverManager.getConnection("jdbc:sqlite:compData.db");
        
    } catch (java.sql.SQLException e) {
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Неуспешна връзка с базата данни! " + e.getMessage());
    }
    return conn;
}    
}

    