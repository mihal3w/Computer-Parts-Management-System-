package app.Classes;

public class Users {

    private int UserID;
    private String Name;
    private String Surname;
    private String Email;
    private int Telephone;
    private String Username;
    private String Password;
    private String Status;

   public Users(String username,String password){
        this.Username = username;
        this.Password = password;
    }
    
    public Users(int id,String name,String surname,String email,int telephone,String username,String password,String status) {
        this.UserID=id;
        this.Name = name;
        this.Surname = surname;
        this.Telephone = telephone;
        this.Email = email;
        this.Username = username;
        this.Password = password;
        this.Status = status;
    }


    
    public int getUserID() {
        return UserID;
    }

    public String getName() {
        return Name;
    }

    public String getSurname() {
        return Surname;
    }

    public String getEmail() {
        return Email;
    }

    public int getTelephone() {
        return Telephone;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public String getStatus() {
        return Status;
    }
}
   
    

