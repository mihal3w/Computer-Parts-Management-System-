package app.Classes;

import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CompParts {
    private int ID_Parts;
    private String ComponentName;
    private String Description;
    private double Price;
    private String Category;
    private String Manufacture;
    private int Quantity;

    public CompParts(String component, String description, double price, String category, String manufacture) {
        this.ComponentName = component;
        this.Description = description;
        this.Price = price;
        this.Category = category;
        this.Manufacture = manufacture;
    }

    public CompParts(int id, String component, String description, double price, String category, String manufacture) {
        this.ID_Parts = id;
        this.ComponentName = component;
        this.Description = description;
        this.Price = price;
        this.Category = category;
        this.Manufacture = manufacture;
    }

    // Getters
    public int getID_Parts() {
        return ID_Parts;
    }

    public String getComponentName() {
        return ComponentName;
    }

    public String getDescription() {
        return Description;
    }

    public double getPrice() {
        return Price;
    }

    public String getCategory() {
        return Category;
    }

    public String getManufacture() {
        return Manufacture;
    }
    
    public int getQuantity(){
    return Quantity;
    }
    
        // Setters
    public void setID_Parts(int ID_Parts) {
        this.ID_Parts = ID_Parts;
    }

    public void setComponentName(String componentName) {
        this.ComponentName = componentName;
    }

    public void setDescription(String description) {
        this.Description = description;
    }

public void setPrice(double price) {
    if (price < 0) {
        throw new IllegalArgumentException("Цената не може да бъде отрицателна.");
    }
    this.Price = price;
}


    public void setCategory(String category) {
        this.Category = category;
    }

    public void setManufacture(String manufacture) {
        this.Manufacture = manufacture;
    }

    public void setQuantity(int quantity) {
        this.Quantity = quantity;
    }
    
    
    public static String getCategoryFilter(String category) {
        if (category != null && !category.equals("Всички")) {
            switch (category) {
                case "Видеокарта":
                    return " WHERE Category = 'Graphics Card'";
                case "Процесор":
                    return " WHERE Category = 'Processor'";
                case "Дънна платка":
                    return " WHERE Category = 'Motherboard'";
                case "Оперативна памет (RAM)":
                    return " WHERE Category = 'RAM'";
                case "Захранване (PSU)":
                    return " WHERE Category = 'PSU'";
                case "Твърд диск (HDD)":
                    return " WHERE Category = 'HDD'";
                case "Диск (SSD)":
                    return " WHERE Category = 'SSD'";
                case "Охладители":
                    return " WHERE Category = 'Coolers'";
                case "Кутия":
                    return " WHERE Category = 'Case'";
                default:
                    return "";
            }
        }
        return "";
    }

// Функция за филтриране по цена
    public static String getPriceFilter(String priceRange) {
        if (priceRange != null && !priceRange.equals("Без лимит")) {
            switch (priceRange) {
                case "0 - 200 лв":
                    return "Price BETWEEN 0 AND 200";
                case "200 - 400 лв":
                    return "Price BETWEEN 200 AND 400";
                case "400 - 1500 лв":
                    return "Price BETWEEN 400 AND 1500"; 
                case "1500 - 3000 лв":
                    return "Price BETWEEN 1500 AND 3000";
                default:
                    return "0 AND 10000";
            }
        }
        return "";
    }
    
    // Функция за производител
    public static String getManufacturerFilter(String manufacturer) {
    if (manufacturer != null && !manufacturer.equals("Всички")) {
        return "Manufacturer = '" + manufacturer + "'";
    }
    return "";
}


    // Метод за зареждане на данни с филтриране
    public static void loadTableDataFiltered(String category, String priceRange, DefaultTableModel table) {
        String sql = "SELECT ID_Parts, ComponentName, Description, Price, Category, Manufacturer FROM Computer_Spec";

        // Добавяне на филтър за категория
        String categoryFilter = getCategoryFilter(category);
        if (!categoryFilter.isEmpty()) {
            sql += categoryFilter;
        }

        // Добавяне на филтър за цена
      String priceFilter = getPriceFilter(priceRange);
        if (!priceFilter.isEmpty()) {
            if (categoryFilter.isEmpty()) {
                sql += " WHERE " + priceFilter;
            } else {
                sql += " AND " + priceFilter;
            }
        }
        
        List<CompParts> partsList = new ArrayList<>();

        try (Connection conn = ConnectionDataBase.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                CompParts part = new CompParts(
                        rs.getInt("ID_Parts"),
                        rs.getString("ComponentName"),
                        rs.getString("Description"),
                        rs.getDouble("Price"),
                        rs.getString("Category"),
                        rs.getString("Manufacturer")
                );
                partsList.add(part);
            }

            table.setRowCount(0);

            // Добавяне на данни в таблицата
            for (CompParts part : partsList) {
                table.addRow(new Object[]{
                        part.getComponentName(),
                        part.getDescription(),
                        part.getPrice(),
                        part.getCategory(),
                        part.getManufacture()
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
        }
    }
    
    
    
}
