package app.Classes;

public class ShoppingCartItem {
    private int partId;
    private String componentName;
    private String description;
    private String manufacturer;
    private double price;
    private int quantity;

    public ShoppingCartItem(int partId, String componentName, String description, String manufacturer, double price, int quantity) {
        this.partId = partId;
        this.componentName = componentName;
        this.description = description;
        this.manufacturer = manufacturer;
        this.price = price;
        this.quantity = quantity;
    }

    public int getPartId() {
        return partId;
    }

    public String getComponentName() {
        return componentName;
    }

    public String getDescription() {
        return description;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return price * quantity;
    }
}
