
package app;

import app.Classes.ConnectionDataBase;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class EmployesCLI extends javax.swing.JFrame {

    DefaultTableModel table = new DefaultTableModel();
    boolean addedRow = false;
    
    public EmployesCLI() {
        initComponents();
        setupComboBox();
        populateTableComboBox(); 
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Платформа за управление - EMPLOYES // MENU ");

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {}
            },
            new String [] {

            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("Update");
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jToggleButton1.setText("New Row");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jButton3.setText("Insert");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Delete Record");
        jButton4.setFocusable(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 6, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 780, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(315, 315, 315))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(156, 156, 156))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jToggleButton1)
                            .addComponent(jButton3))
                        .addGap(110, 110, 110)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1)))
                .addContainerGap(246, Short.MAX_VALUE))
        );

        jButton2.setText("Log Out");
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tech Zone");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 475, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(259, 259, 259)
                        .addComponent(jLabel4)
                        .addGap(534, 534, 534)))
                .addComponent(jButton2)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(143, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        String selectedTable = (String) jComboBox1.getSelectedItem();
        if (selectedTable != null) {
            loadTableData(selectedTable);
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    this.dispose(); 
    LogIn loginScreen = new LogIn(); 
    loginScreen.setVisible(true); 
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        if(addedRow) {
                JOptionPane.showMessageDialog(this, "Първо трябва да довършите операцията с текущия ред!");
            }
        else {
            int selectedRow = jTable1.getSelectedRow(); 

            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Моля, изберете ред за изтриване.", "Грешка", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String selectedTable = (String) jComboBox1.getSelectedItem();
            Object idValue = jTable1.getValueAt(selectedRow, 0); // Взема стойността на първата колона
            String idColumn = jTable1.getColumnName(0); // Взема името на първата колона


            if (idValue == null) {
                JOptionPane.showMessageDialog(this, "Не може да се изтрие ред без валиден идентификатор.", "Грешка", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {

                Connection conn = ConnectionDataBase.connect();
                Statement stmt = conn.createStatement();
                String sql = "DELETE FROM " + selectedTable + " WHERE " + idColumn + " = " + idValue;

                if (selectedTable.equals("Orders")) {
                    stmt = conn.createStatement();
                    stmt.execute("PRAGMA foreign_keys = ON;");
                }
                else {
                    stmt = conn.createStatement();
                    stmt.execute("PRAGMA foreign_keys = OFF;");
                }

                System.out.println(sql);

                int rowsAffected = stmt.executeUpdate(sql);
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Редът е изтрит успешно.");
                    ((DefaultTableModel) jTable1.getModel()).removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(this, "Редът не може да бъде изтрит.", "Грешка", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Грешка при изтриването на реда: " + e.getMessage(), "Грешка", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }      

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked

        for (Component component : jPanel1.getComponents()) {
                    if (component instanceof JLabel || component instanceof JTextField) {
                        jPanel1.remove(component);
                    }
                }
            
        int selectRow = jTable1.getSelectedRow();
        int columnCount = jTable1.getColumnCount();         
        String choice = jComboBox1.getSelectedItem().toString();
        int yPosition = 120;
        
        int skip = 1;
        
        if(choice.equals("Computer_Spec_Supplier") || choice.equals("Computer_Spec_Warehouse") || choice.equals("Order_Spec")) {
            skip = 2;
        }
               
        for (int i=0; i<columnCount; i++) {
            
            if (i<skip) {
                    continue;
            }
            
            JLabel label = new JLabel();
            JTextField field = new JTextField();
            label.setForeground(Color.white);
            Font boldFont = new Font(label.getFont().getName(), Font.BOLD, label.getFont().getSize());
            label.setFont(boldFont);
            label.setText(table.getColumnName(i));
            field.setText("");

            label.setBounds(852, yPosition-20, 200, 30);
            field.setBounds(850, yPosition, 160, 25);
                    
            jPanel1.add(label);
            jPanel1.add(field);

            yPosition += 50;
        }              
     
           
        int counter = skip;
        
        for (Component component : jPanel1.getComponents()) {
            
                Object cellValue = jTable1.getValueAt(selectRow, counter);
                String value = (cellValue != null) ? cellValue.toString() : ""; // Ако стойността е null, задаваме празен текст  
               
                if (component instanceof JTextField) {
                    ((JTextField) component).setText(value);
                    counter++;
                }
            }
        
        this.revalidate();
        this.repaint();

    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButton1ActionPerformed
    {//GEN-HEADEREND:event_jButton1ActionPerformed
        
        if(addedRow) {
            JOptionPane.showMessageDialog(this, "Първо трябва да довършите операцията с текущия ред!");
        }
        else {
            ArrayList<String> tempRows = new ArrayList<String>();
            ArrayList<String> tempColumns = new ArrayList<String>();

            String selectedTable = jComboBox1.getSelectedItem().toString();

            if(selectedTable.equals("Computer_Spec_Supplier") || selectedTable.equals("Computer_Spec_Warehouse") || selectedTable.equals("Order_Spec")) {
                JOptionPane.showMessageDialog(this, "Нямате право да update-нете стойностите на тази таблица!");
            }
            else {
                for (Component component : jPanel1.getComponents()) {

                    if (component instanceof JTextField) {
                        tempRows.add(((JTextField) component).getText());
                    }
                    else if (component instanceof JLabel) {
                        tempColumns.add(((JLabel) component).getText());
                    }
                }

                int selectedRow = jTable1.getSelectedRow();
                String id = jTable1.getValueAt(selectedRow, 0).toString();
                String columnName = table.getColumnName(0);
                try{

                    Connection conn = ConnectionDataBase.connect();
                    Statement stmt = conn.createStatement();
                    String sql = "UPDATE " + selectedTable + " set ";

                    for (int i = 0; i < tempColumns.size(); i++) {
                        sql=sql+tempColumns.get(i)+" = '"+tempRows.get(i)+"', ";
                    }
                    sql=sql.substring(0, sql.length()-2);
                    sql = sql + " WHERE "+ columnName + " = '"+id+"'";

                    ResultSet rs = stmt.executeQuery(sql);

                } catch (SQLException e) {
                    System.out.println(e);
                }


                if (table != null) {
                    table.setRowCount(0);
                    table.setColumnCount(0);
                }

                if (selectedTable != null) {
                    loadTableData(selectedTable);
                }
            }
        }
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jToggleButton1ActionPerformed
    {//GEN-HEADEREND:event_jToggleButton1ActionPerformed
        String selectedTable = jComboBox1.getSelectedItem().toString();
            if(selectedTable.equals("Computer_Spec_Supplier") || selectedTable.equals("Computer_Spec_Warehouse") || selectedTable.equals("Order_Spec")) {
                JOptionPane.showMessageDialog(this, "Нямате право да update-нете стойностите на тази таблица!");
            }
            else {
        if(!addedRow) {
            int columnCount = table.getColumnCount(); 
            String[] emptyRow = new String[columnCount];

            String previousID = jTable1.getValueAt(table.getRowCount()-1, 0).toString();
            String nextID = String.valueOf(Integer.parseInt(previousID) + 1);

            emptyRow[0] = nextID;

            table.addRow(emptyRow);

            addedRow = true;
        }
        else {
            JOptionPane.showMessageDialog(this, "Първо трябва да довършите операцията с текущия ред!");
        }
            }
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButton3ActionPerformed
    {//GEN-HEADEREND:event_jButton3ActionPerformed
        if (addedRow) {
            addedRow = false;
            
            int selectedRow = table.getRowCount();
            int columnCount = table.getColumnCount();
            String selectedTable = jComboBox1.getSelectedItem().toString();
            if(selectedTable.equals("Computer_Spec_Supplier") || selectedTable.equals("Computer_Spec_Warehouse") || selectedTable.equals("Order_Spec")) {
                JOptionPane.showMessageDialog(this, "Нямате право да update-нете стойностите на тази таблица!");
            }
            else {
            
            String[] rowValues = new String[columnCount];
            String[] columnValues = new String[columnCount];
            
            for (int i = 0; i < columnCount; i++) {
               Object cellValue = jTable1.getValueAt(selectedRow-1, i);
               columnValues[i] = jTable1.getColumnName(i);
               rowValues[i] = (cellValue != null) ? cellValue.toString() : ""; // Ако стойността е null, задаваме празен текст
            }
            
            try{
                Connection conn = ConnectionDataBase.connect();
                Statement stmt = conn.createStatement();
                String columns = String.join(", ", columnValues);
                String values = String.join("', '", rowValues);
                String sql = "INSERT INTO " + selectedTable + " ("+columns+") values ('"+values+"')";

                ResultSet rs = stmt.executeQuery(sql);

            } catch (SQLException e) {
                System.out.println(e);
            }
            
        }
        }
        else {
            JOptionPane.showMessageDialog(this, "Не сте добавили нов ред!");
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    public void populateTableComboBox() {
    List<String> tableNames = new ArrayList<>();

    try (Connection conn = ConnectionDataBase.connect() ;
         Statement stmt = conn.createStatement()) {
        String sql = "SELECT name FROM sqlite_master WHERE type='table';";
        ResultSet rs = stmt.executeQuery(sql);
        
        while (rs.next()) {
            String tableName = rs.getString("name");
            tableNames.add(tableName);
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }

    jComboBox1.removeAllItems(); 
    for (String tableName : tableNames) {
        jComboBox1.addItem(tableName);
    }
}


private void setupComboBox() {
        jComboBox1.addActionListener(evt -> {
            String selectedItem = (String) jComboBox1.getSelectedItem();
            if ("Categories".equals(selectedItem)) {
                loadTableData("Categories");
            }
        });
    } 

public void loadTableData(String tableName) {
    DefaultTableModel model = new DefaultTableModel();
    try (Connection conn = ConnectionDataBase.connect();
         Statement stmt = conn.createStatement()) {  
        String sql = "SELECT * FROM " + tableName;
        ResultSet rs = stmt.executeQuery(sql); 

        // Добавяне на колони
        int columnCount = rs.getMetaData().getColumnCount();
        for (int i = 1; i <= columnCount; i++) {
            model.addColumn(rs.getMetaData().getColumnName(i));
        }

        // Добавяне на редове
        while (rs.next()) {
            Object[] row = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                row[i - 1] = rs.getObject(i);
            }
            model.addRow(row);
        }

        jTable1.setModel(model);
        table = model;
        jTable1.setModel(table);

    } catch (Exception e) {
        e.printStackTrace();
    }
}
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployesCLI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployesCLI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployesCLI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployesCLI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployesCLI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables
}
