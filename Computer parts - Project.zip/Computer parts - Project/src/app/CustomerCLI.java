package app;

import app.Classes.CompParts;
import static app.Classes.CompParts.getCategoryFilter;
import static app.Classes.CompParts.getManufacturerFilter;
import static app.Classes.CompParts.getPriceFilter;
import app.Classes.ConnectionDataBase;
import app.Classes.Session;
import app.Classes.ShoppingCartItem;
import app.Classes.Users;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import javax.swing.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class CustomerCLI extends javax.swing.JFrame {
         DefaultTableModel table = new DefaultTableModel() {

        @Override
        public boolean isCellEditable(int row, int column) {

           return false;
        }
    };
    DefaultTableModel tableModel1  = new DefaultTableModel() {

        @Override
        public boolean isCellEditable(int row, int column) {

           return false;
        }
    };
      DefaultTableModel model  = new DefaultTableModel() {

        @Override
        public boolean isCellEditable(int row, int column) {

           return false;
        }
    };
     DefaultTableModel tableModel2  = new DefaultTableModel() {

        @Override
        public boolean isCellEditable(int row, int column) {

           return false;
        }
    };
      DefaultTableModel tableModel  = new DefaultTableModel() {

        @Override
        public boolean isCellEditable(int row, int column) {

           return false;
        }
    };
    
    public CustomerCLI() { 
        initComponents();
        setResizable(false);
        loadTableData(jTable2); 
        table = (DefaultTableModel)jTable2.getModel();
        addTableClickListener(); 
        setupQuantityField();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Име на продукт", "Тип", "Производител", "Цена", "Количество", "Крайна цена"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTable2.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane2.setViewportView(jTable2);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Всички", "Видеокарта", "Процесор", "Дънна платка", "Оперативна памет (RAM)", "Захранване (PSU)", "Твърд диск (HDD)", "Диск (SSD)", "Охладители", "Кутия " }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Без лимит", "0 - 200 лв", "200 - 400 лв", "400 - 1500 лв", "1500 - 3000 лв" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Всички", "Intel", "AMD", "NVIDIA", "AMD", "ASUS", "MSI", "Gigabyte", "ASRock", "Corsair", "G.Skill", "Kingston", "Seagate", "Western Digital (WD)", "Samsung", "Crucial", "Corsair", "EVGA", "Seasonic", "NZXT", "Cooler Master", "Fractal Design", "Noctua", "Cooler Master", "Corsair" }));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jButton1.setText("Принтирай разписка");
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTextField1.setEditable(false);
        jTextField1.setBackground(new java.awt.Color(51, 51, 51));
        jTextField1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jTextField1.setEnabled(false);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Име на продукт");

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Въведете количество");

        jButton2.setBackground(new java.awt.Color(204, 204, 204));
        jButton2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jButton2.setText("Добави продукт");
        jButton2.setFocusPainted(false);
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(204, 204, 204));
        jButton3.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jButton3.setText("Направи Поръчка");
        jButton3.setFocusPainted(false);
        jButton3.setFocusable(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(204, 204, 204));
        jButton4.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jButton4.setText("Изчисти");
        jButton4.setFocusPainted(false);
        jButton4.setFocusable(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Производител");

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Тип");

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Цена");

        jTextField3.setEditable(false);
        jTextField3.setBackground(new java.awt.Color(51, 51, 51));
        jTextField3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jTextField3.setEnabled(false);

        jTextField2.setEditable(false);
        jTextField2.setBackground(new java.awt.Color(51, 51, 51));
        jTextField2.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jTextField2.setEnabled(false);

        jTextField4.setEditable(false);
        jTextField4.setBackground(new java.awt.Color(51, 51, 51));
        jTextField4.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jTextField4.setEnabled(false);

        jTextField5.setText("1");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Поръчай сега от нас");

        jLayeredPane1.setLayer(jTextField1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButton3, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButton4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel7, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel8, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel6, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel10, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextField3, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextField2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextField4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextField5, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                    .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jTextField5))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel10)
                                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(4, 4, 4))
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1)
                                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                        .addGap(13, 13, 13)
                                        .addComponent(jLabel2))))))
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jLabel2)
                .addGap(46, 46, 46)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField5))))
                .addGap(51, 51, 51)
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tech Zone");

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Цена");

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Компоненти");

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Производител");

        jLabel15.setIcon(new javax.swing.ImageIcon("I:\\3ти Курс\\Java\\Test Kursova\\Computer parts - Project\\Pictures\\Config-280x280.jpg")); // NOI18N
        jLabel15.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton5.setBackground(new java.awt.Color(204, 204, 204));
        jButton5.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 0, 0));
        jButton5.setText("Log Out");
        jButton5.setFocusPainted(false);
        jButton5.setFocusable(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 255, 153));
        jLabel9.setText("Кошничка");

        jLabel13.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 255, 153));
        jLabel13.setText("Каталог");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(264, 264, 264)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(74, 74, 74))
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(182, 182, 182)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(166, 166, 166))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(189, 189, 189)))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel15)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addGap(9, 9, 9))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel12)
                                            .addComponent(jLabel11))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(44, 44, 44))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLayeredPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel12)
                                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(29, 29, 29)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel14)
                                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(74, 74, 74)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton5)
                            .addComponent(jLabel4))))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
    
    String selectedCategory = (String) jComboBox2.getSelectedItem();
    String selectedPriceRange = (String) jComboBox1.getSelectedItem();
    String selectedManufacturer = (String) jComboBox3.getSelectedItem();
    loadTableDataFiltered(selectedCategory, selectedPriceRange,selectedManufacturer);
    }//GEN-LAST:event_jComboBox2ActionPerformed

// Метод за зареждане на таблицата с филтри
public void loadTableDataFiltered(String category, String priceRange,String manufacturer) {
    if (table == null) {
        JOptionPane.showMessageDialog(null, "Table is not initialized.");
        return;
    }
    table.setRowCount(0);
    String sql = "SELECT ID_Parts, ComponentName, Description, Price, Category, Manufacturer FROM Computer_Spec";
    String categoryFilter = getCategoryFilter(category);
    String priceFilter =    getPriceFilter(priceRange);
    String manufacturerFilter = getManufacturerFilter(manufacturer);
    
    if (!categoryFilter.isEmpty()) {
        sql += categoryFilter;
    }

    if (!priceFilter.isEmpty()) {
        if (sql.contains("WHERE")) {
            sql += " AND " + priceFilter;
        } else {
            sql += " WHERE " + priceFilter;
        }
    }
    
       if (!manufacturerFilter.isEmpty()) {
        if (sql.contains("WHERE")) {
            sql += " AND " + manufacturerFilter;
        } else {
            sql += " WHERE " + manufacturerFilter;
        }
    }

    List<CompParts> partsList = new ArrayList<>();
    try (Connection conn = ConnectionDataBase.connect();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        while (rs.next()) {
            CompParts part = new CompParts(
                    rs.getInt("ID_Parts"),
                    rs.getString("ComponentName"),
                    rs.getString("Description"),
                    rs.getDouble("Price"),
                    rs.getString("Category"),
                    rs.getString("Manufacturer")
            );
            partsList.add(part);
        }

        table.setRowCount(0);
        for (CompParts part : partsList) {
            table.addRow(new Object[]{
                    part.getID_Parts(),
                    part.getComponentName(),
                    part.getDescription(),
                    part.getPrice(),
                    part.getCategory(),
                    part.getManufacture()
            });
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
    }
}

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed

    String selectedCategory = (String) jComboBox2.getSelectedItem();
    
    String selectedPriceRange = (String) jComboBox1.getSelectedItem();
    String selectedManufacturer = (String) jComboBox3.getSelectedItem();
    loadTableDataFiltered(selectedCategory, selectedPriceRange,selectedManufacturer);
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
                                           
    String selectedCategory = (String) jComboBox2.getSelectedItem();
    String selectedPriceRange = (String) jComboBox1.getSelectedItem();
    String selectedManufacturer = (String) jComboBox3.getSelectedItem();
    
    loadTableDataFiltered(selectedCategory, selectedPriceRange, selectedManufacturer);
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
    int confirm = JOptionPane.showConfirmDialog(this,"Сигурни ли сте, че искате да излезете?","Потвърждение",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
    if (confirm == JOptionPane.YES_OPTION) {
        this.dispose();
        LogIn loginScreen = new LogIn();
        loginScreen.setVisible(true);
        }
    }//GEN-LAST:event_jButton5ActionPerformed
    
    private List<ShoppingCartItem> shoppingCart = new ArrayList<>();
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

    int selectedRow = jTable2.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Моля, изберете продукт от таблицата!", "Грешка", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    tableModel2 = (DefaultTableModel) jTable2.getModel();
    int partId = Integer.parseInt(tableModel2.getValueAt(selectedRow, 0).toString());
    String componentName = tableModel2.getValueAt(selectedRow, 1).toString();
    String description = tableModel2.getValueAt(selectedRow, 2).toString();
    double unitPrice = Double.parseDouble(tableModel2.getValueAt(selectedRow, 3).toString().replace(",", "."));
    String manufacturer = tableModel2.getValueAt(selectedRow, 4).toString();

    String quantityText = jTextField5.getText();
    int quantity;
    try {
        quantity = Integer.parseInt(quantityText);
        if (quantity < 1 || quantity > 9) {
            JOptionPane.showMessageDialog(this, "Количеството трябва да е между 1 и 9!", "Грешка", JOptionPane.ERROR_MESSAGE);
            return;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Невалидно количество! Моля, въведете число между 1 и 9.", "Грешка", JOptionPane.ERROR_MESSAGE);
        return;
    }
    boolean itemExists = false;
    for (ShoppingCartItem item : shoppingCart) {
        if (item.getPartId() == partId) {
            item.setQuantity(item.getQuantity() + quantity);
            itemExists = true;
            break;
        }
    }
    
    if (!itemExists) {
        ShoppingCartItem item = new ShoppingCartItem(partId, componentName, description, manufacturer, unitPrice, quantity);
        shoppingCart.add(item);
    }

    tableModel1 = (DefaultTableModel) jTable1.getModel();
    tableModel1.setRowCount(0);
    for (ShoppingCartItem item : shoppingCart) {
        tableModel1.addRow(new Object[]{
            item.getComponentName(),
            item.getDescription(),
            item.getManufacturer(),
            item.getPrice(),
            item.getQuantity(),
            item.getPrice()* item.getQuantity()
        });
    }

    //общата сума
    double grandTotal = shoppingCart.stream()
        .mapToDouble(cartItem -> cartItem.getPrice() * cartItem.getQuantity())
        .sum();
    jLabel6.setText(String.format("Обща стойност: %.2f", grandTotal));

    JOptionPane.showMessageDialog(this, "Продуктът е добавен успешно!", "Успех", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
                                  
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Моля, изберете ред за изтриване от Кошничката.", "Грешка", JOptionPane.ERROR_MESSAGE);
        return;
    }
    tableModel = (DefaultTableModel) jTable1.getModel();
    String componentName = tableModel.getValueAt(selectedRow, 0).toString();

    // Намираме и премахваме съответния продукт от списъка shoppingCart
    shoppingCart.removeIf(item -> item.getComponentName().equals(componentName));

    tableModel.removeRow(selectedRow);

    updateTotalPrice();

    JOptionPane.showMessageDialog(this, "Избраният ред е изтрит успешно.", "Успешно", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      Users currentUser = Session.getCurrentUser();

    if (currentUser == null) {
        JOptionPane.showMessageDialog(this, "Грешка: Не е намерен текущ потребител.");
        return;
    }

    if (shoppingCart.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Кошницата е празна! Моля, добавете продукти преди да създадете поръчка.", "Грешка", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String[] paymentMethods = {"Карта", "Наложен платеж"};
    String paymentMethod = (String) JOptionPane.showInputDialog(
        this, 
        "Изберете начин на плащане:", 
        "Метод на плащане", 
        JOptionPane.QUESTION_MESSAGE, 
        null, 
        paymentMethods, 
        paymentMethods[0]
    );

    if (paymentMethod == null) {
        JOptionPane.showMessageDialog(this, "Моля, изберете начин на плащане.");
        return;
    }

    try (java.sql.Connection conn = ConnectionDataBase.connect()) {
        conn.setAutoCommit(false);

        try {
            String insertOrderSQL = "INSERT INTO Orders (Users, OrderDate, OrderStatus, PaymentMethod) VALUES (?, CURRENT_TIMESTAMP, 'Обработва се', ?)";
            PreparedStatement orderStmt = conn.prepareStatement(insertOrderSQL, Statement.RETURN_GENERATED_KEYS);
            orderStmt.setInt(1, currentUser.getUserID());
            orderStmt.setString(2, paymentMethod);
            orderStmt.executeUpdate();

            ResultSet generatedKeys = orderStmt.getGeneratedKeys();
            if (!generatedKeys.next()) {
                throw new SQLException("Неуспешно създаване на поръчка.");
            }
            int orderId = generatedKeys.getInt(1);
            
            String insertOrderSpecSQL = "INSERT INTO Order_Spec (ID_Parts, ID_Order, OrderPrice, Quantity) VALUES (?, ?, ?, ?)";
            PreparedStatement orderSpecStmt = conn.prepareStatement(insertOrderSpecSQL);

            for (ShoppingCartItem item : shoppingCart) {
                orderSpecStmt.setInt(1, item.getPartId());
                orderSpecStmt.setInt(2, orderId);
                orderSpecStmt.setBigDecimal(3, BigDecimal.valueOf(item.getPrice() * item.getQuantity()));
                orderSpecStmt.setInt(4, item.getQuantity());
                orderSpecStmt.addBatch();
            }
            orderSpecStmt.executeBatch();

            conn.commit();
            shoppingCart.clear();
            tableModel1 = (DefaultTableModel) jTable1.getModel();
            tableModel1.setRowCount(0);

            jLabel6.setText("Обща стойност: 0.00");
            JOptionPane.showMessageDialog(this, "Поръчката е успешно създадена!", "Успех", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            conn.rollback();
            JOptionPane.showMessageDialog(this, "Грешка при създаването на поръчката: " + e.getMessage());
        } finally {
            conn.setAutoCommit(true);
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Грешка при създаването на поръчката: " + ex.getMessage());
    }
      
    }//GEN-LAST:event_jButton3ActionPerformed
//Отчет за потребител и неговите поръчки които има при логин
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
                              
    Users currentUser = Session.getCurrentUser();

    if (currentUser == null) {
        JOptionPane.showMessageDialog(this, "Грешка: Не е намерен текущ потребител.");
        return;
    }
    String firstName = currentUser.getName();
    String lastName = currentUser.getSurname();

    File reportFolder = new File("Report");
    if (!reportFolder.exists()) {
        reportFolder.mkdir(); 
    }

    String fileName = "Report/Orders_" + firstName + "_" + lastName + ".txt";
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
        writer.write("Вашите поръчки Г-н/Г-жо: " + firstName + " " + lastName);
        writer.newLine();
        writer.write("============================================");
        writer.newLine();

      
        String sql = "SELECT o.ID_Order, o.OrderDate, o.PaymentMethod, os.OrderPrice, os.Quantity, " +
                     "cp.ComponentName " +
                     "FROM Orders o " +
                     "JOIN Order_Spec os ON o.ID_Order = os.ID_Order " +
                     "JOIN Computer_Spec cp ON os.ID_Parts = cp.ID_Parts " +
                     "WHERE o.Users = ?";
        try (Connection conn = ConnectionDataBase.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, currentUser.getUserID());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String orderDate = rs.getString("OrderDate");
                String paymentMethod = rs.getString("PaymentMethod");
                String componentName = rs.getString("ComponentName");
                double orderPrice = rs.getDouble("OrderPrice");
                int quantity = rs.getInt("Quantity");

                writer.write("Дата на поръчка: " + orderDate);
                writer.newLine();
                writer.write("Начин на плащане: " + paymentMethod);
                writer.newLine();
                writer.write("Част: " + componentName + ", Цена: " + orderPrice + ", Количество: " + quantity);
                writer.newLine();
                writer.write("-------------------------------------------------");
                writer.newLine();
            }
        }

        writer.write("Вашият партньор в света на технологиите - Tech Zone!");
        writer.newLine();

        JOptionPane.showMessageDialog(this, "Отчетът е създаден успешно в: " + fileName, "Успех", JOptionPane.INFORMATION_MESSAGE);

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Грешка при записването на отчета: " + e.getMessage(), "Грешка", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Грешка при извличането на данни за поръчките: " + e.getMessage(), "Грешка", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_jButton1ActionPerformed
// Ограничаване на jTextField5 само до числа от 1 до 9 
private void setupQuantityField() {
    
    ((AbstractDocument) jTextField5.getDocument()).setDocumentFilter(new DocumentFilter() {
        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
            String newText = new StringBuilder(currentText).replace(offset, offset + length, text).toString();

            if (newText.matches("[1-9]?")) { 
                super.replace(fb, offset, length, text, attrs);
            }
        }

        @Override
        public void insertString(FilterBypass fb, int offset, String text, AttributeSet attrs) throws BadLocationException {
            String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
            String newText = new StringBuilder(currentText).insert(offset, text).toString();

            if (newText.matches("[1-9]?")) {
                super.insertString(fb, offset, text, attrs);
            }
        }

        @Override
        public void remove(FilterBypass fb, int offset, int length) throws BadLocationException {
            String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
            String newText = new StringBuilder(currentText).delete(offset, offset + length).toString();

            if (newText.matches("[1-9]?") || newText.isEmpty()) { 
                super.remove(fb, offset, length);
            }
        }
    });
}

private void updateTotalPrice() {
    double totalPrice = 0.0;
    tableModel = (DefaultTableModel) jTable1.getModel();
    for (int i = 0; i < tableModel.getRowCount(); i++) {
        String priceText = tableModel.getValueAt(i, 5).toString(); 
        priceText = priceText.replace(",", ".");

        try {
            totalPrice += Double.parseDouble(priceText);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }
    jLabel6.setText("Обща цена: " + String.format("%.2f", totalPrice));
}

    
    
    public void loadTableDataFilteredByPrice(String priceRange) {
    String sql = "SELECT ID_Parts, ComponentName, Description, Price, Category, Manufacturer FROM Computer_Spec";
    
    List<CompParts> partsList = new ArrayList<>();

    try (Connection conn = ConnectionDataBase.connect();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        while (rs.next()) {
            CompParts part = new CompParts(
                    rs.getInt("ID_Parts"),
                    rs.getString("ComponentName"),
                    rs.getString("Description"),
                    rs.getDouble("Price"),
                    rs.getString("Category"),
                    rs.getString("Manufacturer")
            );
            partsList.add(part);
        }

        if (jTable2 != null) {
            model = (DefaultTableModel) jTable2.getModel();
            model.setRowCount(0); 

            for (CompParts part : partsList) {
                model.addRow(new Object[]{
                        part.getComponentName(),
                        part.getDescription(),
                        part.getPrice(),
                        part.getCategory(),
                        part.getManufacture()
                });
            }
        } else {
            JOptionPane.showMessageDialog(null, "Table is not initialized.");
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
    }
}



public static void loadTableData(JTable table) {
    String sql = "SELECT ID_Parts, ComponentName, Description, Price, Category, Manufacturer FROM Computer_Spec";
    List<CompParts> partsList = new ArrayList<>();

    try (Connection conn = ConnectionDataBase.connect();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
        while (rs.next()) {
            CompParts part = new CompParts(
                    rs.getInt("ID_Parts"),
                    rs.getString("ComponentName"),
                    rs.getString("Description"),
                    rs.getDouble("Price"),
                    rs.getString("Category"),
                    rs.getString("Manufacturer")
            );
            partsList.add(part);
        }

        DefaultTableModel model = new DefaultTableModel() {

        @Override
        public boolean isCellEditable(int row, int column) {

           return false;
        }
    };
        
        model.addColumn("ID"); 
        model.addColumn("Component");
        model.addColumn("Description");
        model.addColumn("Price");
        model.addColumn("Category");
        model.addColumn("Manufacturer");

        for (CompParts part : partsList) {
            model.addRow(new Object[]{
                    part.getID_Parts(),       
                    part.getComponentName(),
                    part.getDescription(),
                    part.getPrice(),
                    part.getCategory(),
                    part.getManufacture()
            });
        }

        table.setModel(model);
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
    }
}

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerCLI().setVisible(true);
            }
        });
    }
    
   
    
private void addTableClickListener() {
    jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            int selectedRow = jTable2.getSelectedRow();
            if (selectedRow != -1) {
                tableModel = (DefaultTableModel) jTable2.getModel();
                
                String componentName = tableModel.getValueAt(selectedRow, 1).toString(); 
                String description = tableModel.getValueAt(selectedRow, 2).toString();   
                String price = tableModel.getValueAt(selectedRow, 3).toString();       
                String manufacturer = tableModel.getValueAt(selectedRow, 5).toString();

                jTextField1.setText(componentName);
                jTextField3.setText(description);
                jTextField2.setText(manufacturer);
                jTextField4.setText(price);

                double unitPrice = Double.parseDouble(price.replace(",", "."));
                double totalPrice = unitPrice * 1; 
                
            }
        }
    });
}
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
